test = {
  'name': 'Question 9_6',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> read == 1
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
