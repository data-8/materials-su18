test = {
  'name': 'Question 9_4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> gradescope == 18969
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
