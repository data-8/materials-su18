test = {
  'name': 'Question 9_5',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> acceptable == 2
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
