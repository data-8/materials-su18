test = {
  'name': 'Question 3_5',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> lower_end > 5
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> upper_end < 15
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
