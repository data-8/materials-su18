test = {
  'name': 'Question 4_5',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> valid_statistic in [1,2,3]
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> valid_statistic == 2
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
