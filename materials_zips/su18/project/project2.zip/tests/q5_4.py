test = {
  'name': 'Question 5.4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> larger_hazard_rate in ['diet', 'control']
          True
          >>> signed_rate_difference in [obs_65_plus, -1 * obs_65_plus]
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
