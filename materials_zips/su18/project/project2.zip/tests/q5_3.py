test = {
  'name': 'Question 5.3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> .03 <= obs_65_plus <= .04
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
