test = {
  'name': 'Question 4.2.5',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> .001 <= death_rates_ts <= .006
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
