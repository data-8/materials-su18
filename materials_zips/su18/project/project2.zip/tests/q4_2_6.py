test = {
  'name': 'Question 4.2.6',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> .2 <= our_p_value <= .4
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
